import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Code, Users, Target, TrendingUp, Zap, GitBranch, TestTube, Clock, CheckCircle, ArrowRight, Cpu, Settings, BarChart3 } from 'lucide-react';

const Presentation = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    // Slide 1 - Título
    {
      id: 'title',
      component: (
        <div className="flex flex-col items-center justify-center h-full text-center">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 mb-6">
              <Code className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            CloudCode
          </h1>
          <h2 className="text-3xl font-light text-gray-700 mb-4">
            Estratégia de Adoção para Engineering Teams
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600">
            Piloto de Transformação no Fluxo de Desenvolvimento
          </p>
        </div>
      )
    },

    // Slide 2 - O Momento Ideal
    {
      id: 'timing',
      component: (
        <div className="h-full">
          <h1 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            O Momento Ideal
          </h1>
          <div className="grid grid-cols-2 gap-8 h-3/4">
            <div className="space-y-6">
              <div className="p-6 bg-green-50 rounded-xl border border-green-200">
                <CheckCircle className="w-8 h-8 text-green-600 mb-4" />
                <h3 className="text-xl font-semibold text-green-800 mb-2">Framework Hexagonal</h3>
                <p className="text-green-700">Novo framework backend criado e pronto para validação</p>
              </div>
              <div className="p-6 bg-blue-50 rounded-xl border border-blue-200">
                <Settings className="w-8 h-8 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold text-blue-800 mb-2">Guidelines Atualizadas</h3>
                <p className="text-blue-700">Novos padrões de desenvolvimento estabelecidos</p>
              </div>
            </div>
            <div className="space-y-6">
              <div className="p-6 bg-purple-50 rounded-xl border border-purple-200">
                <Target className="w-8 h-8 text-purple-600 mb-4" />
                <h3 className="text-xl font-semibold text-purple-800 mb-2">Projetos Reais</h3>
                <p className="text-purple-700">Matrix e ODI como casos de uso concretos</p>
              </div>
              <div className="p-6 bg-orange-50 rounded-xl border border-orange-200">
                <Zap className="w-8 h-8 text-orange-600 mb-4" />
                <h3 className="text-xl font-semibold text-orange-800 mb-2">CloudCode Disponível</h3>
                <p className="text-orange-700">Tecnologia madura e pronta para implementação</p>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // Slide 3 - Novo Fluxo de Trabalho
    {
      id: 'workflow',
      component: (
        <div className="h-full">
          <h1 className="text-4xl font-bold mb-8 text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Transformação no Fluxo de Trabalho
          </h1>
          <div className="flex items-center justify-between h-3/4">
            <div className="w-2/5 space-y-4">
              <h3 className="text-2xl font-semibold text-gray-800 mb-6">Fluxo Atual</h3>
              <div className="space-y-3">
                <div className="p-4 bg-gray-100 rounded-lg">
                  <p className="text-gray-700">💭 Penso na solução</p>
                </div>
                <div className="p-4 bg-gray-100 rounded-lg">
                  <p className="text-gray-700">⌨️ Escrevo o código</p>
                </div>
                <div className="p-4 bg-gray-100 rounded-lg">
                  <p className="text-gray-700">🐛 Corrijo bugs</p>
                </div>
                <div className="p-4 bg-gray-100 rounded-lg">
                  <p className="text-gray-700">📝 Documento depois</p>
                </div>
              </div>
            </div>
            
            <div className="w-1/5 flex justify-center">
              <ArrowRight className="w-12 h-12 text-blue-500" />
            </div>

            <div className="w-2/5 space-y-4">
              <h3 className="text-2xl font-semibold text-blue-800 mb-6">Novo Fluxo CloudCode</h3>
              <div className="space-y-3">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-blue-700">🔍 <strong>Discovery:</strong> Analiso o que preciso</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-blue-700">📋 <strong>Plano:</strong> CloudCode detalha a solução</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-blue-700">✅ <strong>Revisão:</strong> Aprovo e refino o plano</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-blue-700">⚡ <strong>Execução:</strong> CloudCode implementa</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-blue-700">📖 <strong>Documentação:</strong> Automática</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // Slide 4 - Agentes Customizados
    {
      id: 'agents',
      component: (
        <div className="h-full">
          <h1 className="text-4xl font-bold mb-6 text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Agentes Especializados
          </h1>
          <p className="text-center text-lg text-gray-600 mb-8">Execução Sequencial Automatizada</p>
          
          <div className="space-y-6">
            {/* Row 1 - Python Pro and Test Engineer */}
            <div className="flex items-center justify-center space-x-6">
              {/* Agent 1 - Python Pro */}
              <div className="relative">
                <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-xl border-2 border-green-200 shadow-lg w-64">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">1</div>
                    <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                      <Cpu className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-green-800 mb-2">Python Pro</h3>
                  <ul className="text-green-700 space-y-1 text-xs">
                    <li>• Especialista em Python</li>
                    <li>• Best practices automáticas</li>
                    <li>• Code review integrado</li>
                  </ul>
                </div>
              </div>

              {/* Arrow 1 */}
              <div className="flex flex-col items-center px-2">
                <ArrowRight className="w-6 h-6 text-blue-500 mb-1" />
                <span className="text-xs text-gray-500 font-semibold">ENTÃO</span>
              </div>

              {/* Agent 2 - Test Engineer */}
              <div className="relative">
                <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-xl border-2 border-purple-200 shadow-lg w-64">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">2</div>
                    <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                      <TestTube className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-purple-800 mb-2">Test Engineer</h3>
                  <ul className="text-purple-700 space-y-1 text-xs">
                    <li>• Testes automatizados</li>
                    <li>• Coverage reports</li>
                    <li>• Quality assurance</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Vertical Arrow */}
            <div className="flex justify-center">
              <div className="flex flex-col items-center">
                <div className="w-1 h-8 bg-blue-400"></div>
                <div className="w-0 h-0 border-l-4 border-r-4 border-t-8 border-transparent border-t-blue-500"></div>
                <span className="text-xs text-gray-500 font-semibold mt-1">ENTÃO</span>
              </div>
            </div>

            {/* Row 2 - Dr. Doc and GitFlow Master */}
            <div className="flex items-center justify-center space-x-6">
              {/* Agent 3 - Dr. Doc */}
              <div className="relative">
                <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-4 rounded-xl border-2 border-yellow-200 shadow-lg w-64">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">3</div>
                    <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center">
                      <BarChart3 className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-yellow-800 mb-2">Dr. Doc</h3>
                  <ul className="text-yellow-700 space-y-1 text-xs">
                    <li>• Documentação automática</li>
                    <li>• README generation</li>
                    <li>• API documentation</li>
                  </ul>
                </div>
              </div>

              {/* Arrow 3 */}
              <div className="flex flex-col items-center px-2">
                <ArrowRight className="w-6 h-6 text-blue-500 mb-1" />
                <span className="text-xs text-gray-500 font-semibold">ENTÃO</span>
              </div>

              {/* Agent 4 - GitFlow Master */}
              <div className="relative">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-xl border-2 border-blue-200 shadow-lg w-64">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">4</div>
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                      <GitBranch className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-blue-800 mb-2">GitFlow Master</h3>
                  <ul className="text-blue-700 space-y-1 text-xs">
                    <li>• Gerenciamento de branches</li>
                    <li>• Commits padronizados</li>
                    <li>• Release automation</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-6">
            <div className="inline-flex items-center bg-gradient-to-r from-blue-50 to-purple-50 px-6 py-3 rounded-full border border-blue-200">
              <Zap className="w-5 h-5 text-blue-600 mr-2" />
              <p className="text-lg font-semibold text-gray-700">
                <strong>Comando Único:</strong> Executa toda a sequência automaticamente
              </p>
            </div>
          </div>
        </div>
      )
    },

    // Slide 5 - Estrutura do Piloto
    {
      id: 'pilot',
      component: (
        <div className="h-full">
          <h1 className="text-4xl font-bold mb-8 text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Estrutura do Piloto
          </h1>
          <div className="grid grid-cols-2 gap-12 h-3/4">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl border-2 border-blue-200 shadow-lg">
                <Users className="w-10 h-10 text-blue-600 mb-4" />
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">Equipe Selecionada</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-green-500 rounded-full mr-3"></div>
                    <span className="text-gray-700"><strong>2 Seniors Backend</strong></span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-blue-500 rounded-full mr-3"></div>
                    <span className="text-gray-700"><strong>2 Seniors Frontend</strong></span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-purple-500 rounded-full mr-3"></div>
                    <span className="text-gray-700"><strong>Experiência + Feedback qualificado</strong></span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl border-2 border-green-200 shadow-lg">
                <Target className="w-10 h-10 text-green-600 mb-4" />
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">Projetos Piloto</h3>
                <div className="space-y-2">
                  <p className="text-gray-700">• <strong>Matrix:</strong> Framework hexagonal</p>
                  <p className="text-gray-700">• <strong>ODI:</strong> Guidelines aplicadas</p>
                  <p className="text-gray-700">• <strong>Casos reais:</strong> Teste genuíno</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl border-2 border-orange-200 shadow-lg">
                <Clock className="w-10 h-10 text-orange-600 mb-4" />
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">Timeline</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3 text-orange-600 font-bold text-sm">6</div>
                    <span className="text-gray-700"><strong>6 semanas de duração</strong></span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3 text-orange-600 font-bold text-sm">📅</div>
                    <span className="text-gray-700"><strong>Reuniões diárias</strong></span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3 text-orange-600 font-bold text-sm">📊</div>
                    <span className="text-gray-700"><strong>Feedback contínuo</strong></span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl border-2 border-purple-200 shadow-lg">
                <Settings className="w-10 h-10 text-purple-600 mb-4" />
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">Evolução Colaborativa</h3>
                <div className="space-y-2">
                  <p className="text-gray-700">• Times sugerem novos agentes</p>
                  <p className="text-gray-700">• Refinamento conjunto</p>
                  <p className="text-gray-700">• Criação de comandos personalizados</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // Slide 6 - Métricas de Sucesso
    {
      id: 'metrics',
      component: (
        <div className="h-full">
          <h1 className="text-4xl font-bold mb-8 text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Como Mediremos o Sucesso
          </h1>
          <div className="grid grid-cols-2 gap-8 h-3/4">
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">Métricas Quantitativas</h3>
              <div className="space-y-4">
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center">
                    <TrendingUp className="w-6 h-6 text-green-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-green-800">Lead Time</h4>
                      <p className="text-green-700 text-sm">Tempo de entrega das user stories</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center">
                    <Clock className="w-6 h-6 text-blue-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-blue-800">Code Review Time</h4>
                      <p className="text-blue-700 text-sm">Tempo de revisão de código</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                  <div className="flex items-center">
                    <TestTube className="w-6 h-6 text-red-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-red-800">Bug Count</h4>
                      <p className="text-red-700 text-sm">Bugs encontrados em QA/Produção</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <div className="flex items-center">
                    <Zap className="w-6 h-6 text-purple-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-purple-800">Setup Time</h4>
                      <p className="text-purple-700 text-sm">Tempo para iniciar novos projetos</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">Métricas Qualitativas</h3>
              <div className="space-y-4">
                <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex items-center">
                    <CheckCircle className="w-6 h-6 text-yellow-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-yellow-800">Aderência Guidelines</h4>
                      <p className="text-yellow-700 text-sm">Consistência nos padrões</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-200">
                  <div className="flex items-center">
                    <Users className="w-6 h-6 text-indigo-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-indigo-800">Satisfação da Equipe</h4>
                      <p className="text-indigo-700 text-sm">Experiência com novo fluxo</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-teal-50 rounded-lg border border-teal-200">
                  <div className="flex items-center">
                    <BarChart3 className="w-6 h-6 text-teal-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-teal-800">Consistência Código</h4>
                      <p className="text-teal-700 text-sm">Uniformidade entre devs</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                  <div className="flex items-center">
                    <Target className="w-6 h-6 text-orange-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-orange-800">Framework Adoption</h4>
                      <p className="text-orange-700 text-sm">Curva aprendizado hexagonal</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // Slide 7 - Próximos Passos
    {
      id: 'nextsteps',
      component: (
        <div className="h-full">
          <h1 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Próximos Passos
          </h1>
          <div className="flex justify-center">
            <div className="max-w-4xl w-full">
              <div className="space-y-6">
                <div className="flex items-center p-6 bg-white rounded-xl border-l-4 border-blue-500 shadow-lg">
                  <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-xl mr-6">1</div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">Aprovação do Piloto</h3>
                    <p className="text-gray-600">Definir formalmente os recursos e timeline</p>
                  </div>
                </div>

                <div className="flex items-center p-6 bg-white rounded-xl border-l-4 border-green-500 shadow-lg">
                  <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-xl mr-6">2</div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">Seleção da Equipe</h3>
                    <p className="text-gray-600">Escolher os 4 desenvolvedores seniors participantes</p>
                  </div>
                </div>

                <div className="flex items-center p-6 bg-white rounded-xl border-l-4 border-purple-500 shadow-lg">
                  <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-xl mr-6">3</div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">Setup e Treinamento</h3>
                    <p className="text-gray-600">Configurar ambiente e apresentar os agentes existentes</p>
                  </div>
                </div>

                <div className="flex items-center p-6 bg-white rounded-xl border-l-4 border-orange-500 shadow-lg">
                  <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl mr-6">4</div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">Início do Piloto</h3>
                    <p className="text-gray-600">6 semanas de implementação com acompanhamento diário</p>
                  </div>
                </div>

                <div className="flex items-center p-6 bg-white rounded-xl border-l-4 border-red-500 shadow-lg">
                  <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center text-white font-bold text-xl mr-6">5</div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">Avaliação e Escala</h3>
                    <p className="text-gray-600">Análise de resultados e plano de expansão para outros times</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // Slide 8 - Conclusão
    {
      id: 'conclusion',
      component: (
        <div className="flex flex-col items-center justify-center h-full text-center">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-green-500 to-blue-500 mb-6">
              <Zap className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-green-500 to-blue-500 bg-clip-text text-transparent">
            Vamos Transformar
          </h1>
          <h2 className="text-2xl font-light text-gray-700 mb-8">
            nosso processo de desenvolvimento
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto mb-8"></div>
          
          <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-200 max-w-2xl">
            <div className="grid grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-blue-600">6</div>
                <div className="text-sm text-gray-600">Semanas</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600">4</div>
                <div className="text-sm text-gray-600">Seniors</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-600">∞</div>
                <div className="text-sm text-gray-600">Possibilidades</div>
              </div>
            </div>
          </div>

          <p className="text-lg text-gray-600 mt-8 max-w-2xl">
            Um piloto estruturado para validar a próxima geração do desenvolvimento de software em nossa empresa
          </p>
        </div>
      )
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div className="h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex flex-col">
      {/* Main Content */}
      <div className="flex-1 p-8">
        <div className="h-full bg-white rounded-2xl shadow-2xl border border-gray-200 p-8">
          {slides[currentSlide].component}
        </div>
      </div>

      {/* Navigation */}
      <div className="p-6 bg-white shadow-lg">
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          {/* Previous Button */}
          <button
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className={`flex items-center px-6 py-3 rounded-full transition-all ${
              currentSlide === 0
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-blue-500 text-white hover:bg-blue-600 shadow-lg hover:shadow-xl transform hover:-translate-y-1'
            }`}
          >
            <ChevronLeft className="w-5 h-5 mr-2" />
            Anterior
          </button>

          {/* Slide Indicators */}
          <div className="flex space-x-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-4 h-4 rounded-full transition-all ${
                  index === currentSlide
                    ? 'bg-blue-500 scale-125'
                    : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>

          {/* Next Button */}
          <button
            onClick={nextSlide}
            disabled={currentSlide === slides.length - 1}
            className={`flex items-center px-6 py-3 rounded-full transition-all ${
              currentSlide === slides.length - 1
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-blue-500 text-white hover:bg-blue-600 shadow-lg hover:shadow-xl transform hover:-translate-y-1'
            }`}
          >
            Próximo
            <ChevronRight className="w-5 h-5 ml-2" />
          </button>
        </div>

        {/* Slide Counter */}
        <div className="text-center mt-4 text-gray-500 text-sm">
          {currentSlide + 1} de {slides.length}
        </div>
      </div>
    </div>
  );
};

export default Presentation;

// npm install lucide-react